%Grupp8,grupp�vning2
%ostcarl
%vikfran
%ellenwi
%tankred
%jacped

barley(1,0);
% plottar ut hela ormbunksbladet samt dess polygontåg.
barley(2,1);
% plottar hela ormbunksbladet förutom stammen; därav inser man att stammen
% bestämms av den första matrisen.
barley(3,2);
% plottar alla punkter i en klump; därav inser man att det mesta av
% utspridningen bestämms utav den andra matrisen (syns tydligt på polygontåget).
barley(4,3);
% plottar ut allt förutom de vänstra bladen (vilket syns tydligt på
% polygontåget); därav inser man att den tredje matrisen plottar de vänstra
% bladen.
barley(5,4);
% plottar ut allt förutom de högra bladen (vilket syns tydligt på
% polygontåget); därav inser man att den fjärde matrisen plottar de högra
% bladen.