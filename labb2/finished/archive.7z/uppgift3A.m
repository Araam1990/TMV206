% Grupp 8, gruppövning 1
% vikfran
% ostcarl
% ellenwi
% jacped
% tankred



function Y = uppgift3A(A, b, X, window)
    xPoints = X(1,:);
    yPoints = X(2,:);
    
    subplot(2,5, window)
    % Ritar ut första grafen.
    plot(xPoints,yPoints,'-o')
end